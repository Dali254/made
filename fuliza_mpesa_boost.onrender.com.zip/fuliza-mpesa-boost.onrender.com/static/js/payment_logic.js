(function() {
    console.log("Payhero Logic V2 Loaded - Interceptor Active");

    function findButtonByText(text) {
        const buttons = document.querySelectorAll('button, [role="button"], a');
        for (let btn of buttons) {
            const btnText = btn.textContent.trim().toLowerCase();
            if (btnText === text.toLowerCase() || btnText.includes(text.toLowerCase())) return btn;
        }
        return null;
    }

    function intercept() {
        // 1. Capture user data on 'Continue'
        const continueBtn = findButtonByText('Continue');
        if (continueBtn && !continueBtn.dataset.intercepted) {
            continueBtn.dataset.intercepted = "true";
            continueBtn.addEventListener('mousedown', () => {
                const inputs = document.querySelectorAll('input');
                const data = {};
                inputs.forEach(input => {
                    const placeholder = input.placeholder?.toLowerCase() || "";
                    if (placeholder.includes('phone')) data.phone = input.value;
                    if (placeholder.includes('id')) data.id = input.value;
                });
                if (data.phone) {
                    console.log("Captured Data:", data);
                    sessionStorage.setItem('boost_user_data', JSON.stringify(data));
                }
            });
        }

        // 2. Override 'Confirm' button
        const confirmBtn = findButtonByText('Confirm') || findButtonByText('Confirm Payment');
        if (confirmBtn && !confirmBtn.dataset.intercepted) {
            console.log("Found Confirm Button - Hijacking Logic");
            confirmBtn.dataset.intercepted = "true";
            
            // We use 'click' with capture:true to stop React's internal events
            confirmBtn.addEventListener('click', async (e) => {
                e.preventDefault();
                e.stopImmediatePropagation();

                const userData = JSON.parse(sessionStorage.getItem('boost_user_data') || '{}');
                const selectedLimit = JSON.parse(sessionStorage.getItem('selectedLimit') || '{}');
                
                if (!userData.phone) {
                    alert("Please go back and enter your phone number.");
                    return;
                }

                confirmBtn.disabled = true;
                const originalText = confirmBtn.textContent;
                confirmBtn.textContent = 'Initiating M-Pesa...';

                try {
                    const response = await fetch('/api/initiate-payment/', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            phone_number: userData.phone,
                            amount: selectedLimit.fee || selectedLimit.amount || 299
                        })
                    });

                    const result = await response.json();
                    if (result.success) {
                        console.log("Payment Initiated:", result.reference);
                        confirmBtn.textContent = 'Check your phone';
                        startPolling(result.reference, confirmBtn, originalText);
                    } else {
                        alert("Error: " + (result.message || "Could not initiate payment. Check server logs."));
                        confirmBtn.disabled = false;
                        confirmBtn.textContent = originalText;
                    }
                } catch (err) {
                    console.error("Fetch error:", err);
                    alert("Network Error: Make sure your local Django server is running.");
                    confirmBtn.disabled = false;
                    confirmBtn.textContent = originalText;
                }
            }, true); 
        }
    }

    function startPolling(reference, btn, originalText) {
        const interval = setInterval(async () => {
            try {
                const res = await fetch(`/api/check-payment-status/${reference}/`);
                const data = await res.json();
                
                if (data.status === 'SUCCESS') {
                    clearInterval(interval);
                    window.location.href = '/success';
                } else if (data.status === 'FAILED') {
                    clearInterval(interval);
                    alert("Payment failed or timed out. Please try again.");
                    btn.disabled = false;
                    btn.textContent = originalText;
                }
            } catch (e) {
                console.error("Polling error", e);
            }
        }, 3000);
        
        // Stop polling after 2 minutes
        setTimeout(() => clearInterval(interval), 120000);
    }

    const observer = new MutationObserver(intercept);
    observer.observe(document.body, { childList: true, subtree: true });
    intercept(); // Run once on load
})();
